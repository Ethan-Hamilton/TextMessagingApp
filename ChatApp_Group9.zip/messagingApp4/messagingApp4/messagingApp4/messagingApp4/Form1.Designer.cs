﻿
namespace messagingApp4
{
    partial class MessagingApp4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MessagingApp4));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label3 = new System.Windows.Forms.Label();
            this.listBox7 = new System.Windows.Forms.ListBox();
            this.listBox6 = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.listBox5 = new System.Windows.Forms.ListBox();
            this.btnSend2 = new System.Windows.Forms.Button();
            this.lstMessages2 = new System.Windows.Forms.ListBox();
            this.txtTypeText2 = new System.Windows.Forms.TextBox();
            this.lstConnectedClients = new System.Windows.Forms.ListBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.listBox4 = new System.Windows.Forms.ListBox();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.lstGroupUsers = new System.Windows.Forms.ListBox();
            this.lblConncetionStatus = new System.Windows.Forms.Label();
            this.btnSend = new System.Windows.Forms.Button();
            this.lstMessages = new System.Windows.Forms.ListBox();
            this.txtTypeText = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1345, 721);
            this.tabControl1.TabIndex = 4;
            // 
            // tabPage1
            // 
            this.tabPage1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.listBox7);
            this.tabPage1.Controls.Add(this.listBox6);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.listBox5);
            this.tabPage1.Controls.Add(this.btnSend2);
            this.tabPage1.Controls.Add(this.lstMessages2);
            this.tabPage1.Controls.Add(this.txtTypeText2);
            this.tabPage1.Controls.Add(this.lstConnectedClients);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1337, 695);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "PRIVATE CHAT";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Old Antic Decorative", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(684, 5);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(186, 38);
            this.label3.TabIndex = 18;
            this.label3.Text = "MESSAGES";
            // 
            // listBox7
            // 
            this.listBox7.BackColor = System.Drawing.Color.Navy;
            this.listBox7.FormattingEnabled = true;
            this.listBox7.Location = new System.Drawing.Point(1253, -3);
            this.listBox7.Name = "listBox7";
            this.listBox7.Size = new System.Drawing.Size(135, 693);
            this.listBox7.TabIndex = 17;
            // 
            // listBox6
            // 
            this.listBox6.BackColor = System.Drawing.Color.Navy;
            this.listBox6.FormattingEnabled = true;
            this.listBox6.Location = new System.Drawing.Point(-21, 589);
            this.listBox6.Name = "listBox6";
            this.listBox6.Size = new System.Drawing.Size(1696, 108);
            this.listBox6.TabIndex = 16;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Navy;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(6, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(307, 20);
            this.label2.TabIndex = 15;
            this.label2.Text = "SELECT USER FOR PRIVATE CHAT";
            // 
            // listBox5
            // 
            this.listBox5.BackColor = System.Drawing.Color.Navy;
            this.listBox5.FormattingEnabled = true;
            this.listBox5.Location = new System.Drawing.Point(-2, 43);
            this.listBox5.Name = "listBox5";
            this.listBox5.Size = new System.Drawing.Size(334, 43);
            this.listBox5.TabIndex = 14;
            // 
            // btnSend2
            // 
            this.btnSend2.BackColor = System.Drawing.Color.Navy;
            this.btnSend2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSend2.Font = new System.Drawing.Font("DecoType Naskh", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnSend2.ForeColor = System.Drawing.Color.White;
            this.btnSend2.Location = new System.Drawing.Point(1101, 538);
            this.btnSend2.Name = "btnSend2";
            this.btnSend2.Size = new System.Drawing.Size(133, 26);
            this.btnSend2.TabIndex = 13;
            this.btnSend2.Text = "Send";
            this.btnSend2.UseVisualStyleBackColor = false;
            this.btnSend2.Click += new System.EventHandler(this.btnSend2_Click);
            // 
            // lstMessages2
            // 
            this.lstMessages2.FormattingEnabled = true;
            this.lstMessages2.Location = new System.Drawing.Point(338, 46);
            this.lstMessages2.Name = "lstMessages2";
            this.lstMessages2.Size = new System.Drawing.Size(896, 485);
            this.lstMessages2.TabIndex = 11;
            // 
            // txtTypeText2
            // 
            this.txtTypeText2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTypeText2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTypeText2.Location = new System.Drawing.Point(338, 538);
            this.txtTypeText2.Multiline = true;
            this.txtTypeText2.Name = "txtTypeText2";
            this.txtTypeText2.Size = new System.Drawing.Size(757, 26);
            this.txtTypeText2.TabIndex = 12;
            // 
            // lstConnectedClients
            // 
            this.lstConnectedClients.FormattingEnabled = true;
            this.lstConnectedClients.Location = new System.Drawing.Point(-2, 92);
            this.lstConnectedClients.Name = "lstConnectedClients";
            this.lstConnectedClients.Size = new System.Drawing.Size(334, 472);
            this.lstConnectedClients.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.listBox4);
            this.tabPage2.Controls.Add(this.listBox3);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.listBox2);
            this.tabPage2.Controls.Add(this.lstGroupUsers);
            this.tabPage2.Controls.Add(this.lblConncetionStatus);
            this.tabPage2.Controls.Add(this.btnSend);
            this.tabPage2.Controls.Add(this.lstMessages);
            this.tabPage2.Controls.Add(this.txtTypeText);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1337, 695);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "GROUP CHAT";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Old Antic Decorative", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(700, 2);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(186, 38);
            this.label4.TabIndex = 19;
            this.label4.Text = "MESSAGES";
            // 
            // listBox4
            // 
            this.listBox4.BackColor = System.Drawing.Color.Navy;
            this.listBox4.FormattingEnabled = true;
            this.listBox4.Location = new System.Drawing.Point(1278, -24);
            this.listBox4.Name = "listBox4";
            this.listBox4.Size = new System.Drawing.Size(135, 693);
            this.listBox4.TabIndex = 16;
            // 
            // listBox3
            // 
            this.listBox3.BackColor = System.Drawing.Color.Navy;
            this.listBox3.FormattingEnabled = true;
            this.listBox3.Location = new System.Drawing.Point(-2, 559);
            this.listBox3.Name = "listBox3";
            this.listBox3.Size = new System.Drawing.Size(1696, 108);
            this.listBox3.TabIndex = 15;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Navy;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(82, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(141, 20);
            this.label1.TabIndex = 14;
            this.label1.Text = "ONLINE USERS";
            // 
            // listBox2
            // 
            this.listBox2.BackColor = System.Drawing.Color.Navy;
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Location = new System.Drawing.Point(-6, 43);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(328, 43);
            this.listBox2.TabIndex = 13;
            // 
            // lstGroupUsers
            // 
            this.lstGroupUsers.FormattingEnabled = true;
            this.lstGroupUsers.Location = new System.Drawing.Point(-2, 91);
            this.lstGroupUsers.Name = "lstGroupUsers";
            this.lstGroupUsers.Size = new System.Drawing.Size(324, 446);
            this.lstGroupUsers.TabIndex = 12;
            // 
            // lblConncetionStatus
            // 
            this.lblConncetionStatus.AutoSize = true;
            this.lblConncetionStatus.Location = new System.Drawing.Point(41, 14);
            this.lblConncetionStatus.Name = "lblConncetionStatus";
            this.lblConncetionStatus.Size = new System.Drawing.Size(79, 13);
            this.lblConncetionStatus.TabIndex = 11;
            this.lblConncetionStatus.Text = "Not Connected";
            // 
            // btnSend
            // 
            this.btnSend.BackColor = System.Drawing.Color.Navy;
            this.btnSend.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSend.Font = new System.Drawing.Font("DecoType Naskh", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnSend.ForeColor = System.Drawing.Color.White;
            this.btnSend.Location = new System.Drawing.Point(1139, 512);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(118, 25);
            this.btnSend.TabIndex = 10;
            this.btnSend.Text = "Send";
            this.btnSend.UseVisualStyleBackColor = false;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click_1);
            // 
            // lstMessages
            // 
            this.lstMessages.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lstMessages.Font = new System.Drawing.Font("Segoe Fluent Icons", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstMessages.FormattingEnabled = true;
            this.lstMessages.HorizontalScrollbar = true;
            this.lstMessages.ItemHeight = 16;
            this.lstMessages.Location = new System.Drawing.Point(328, 43);
            this.lstMessages.Name = "lstMessages";
            this.lstMessages.Size = new System.Drawing.Size(929, 450);
            this.lstMessages.TabIndex = 8;
            // 
            // txtTypeText
            // 
            this.txtTypeText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTypeText.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTypeText.Location = new System.Drawing.Point(328, 512);
            this.txtTypeText.Multiline = true;
            this.txtTypeText.Name = "txtTypeText";
            this.txtTypeText.Size = new System.Drawing.Size(805, 25);
            this.txtTypeText.TabIndex = 9;
            // 
            // MessagingApp4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1364, 735);
            this.Controls.Add(this.tabControl1);
            this.HelpButton = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MessagingApp4";
            this.Text = "CHAT APP";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label lblConncetionStatus;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.ListBox lstMessages;
        private System.Windows.Forms.TextBox txtTypeText;
        private System.Windows.Forms.Button btnSend2;
        private System.Windows.Forms.ListBox lstMessages2;
        private System.Windows.Forms.TextBox txtTypeText2;
        private System.Windows.Forms.ListBox lstConnectedClients;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.ListBox lstGroupUsers;
        private System.Windows.Forms.ListBox listBox3;
        private System.Windows.Forms.ListBox listBox4;
        private System.Windows.Forms.ListBox listBox5;
        private System.Windows.Forms.ListBox listBox7;
        private System.Windows.Forms.ListBox listBox6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}

